from flask import Flask, request, jsonify, render_template
from groq import Groq
import os

app = Flask(__name__)

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    try:
        data = request.get_json()
        name = data.get("name", "").strip()
        category = data.get("category", "").strip()

        if not name or not category:
            return jsonify({"error": "Product name and category are required."}), 400

        prompt = f"Write a short, attractive, and professional product description for:\nProduct: {name}\nCategory: {category}"

        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "user",
                    "content": prompt,
                }
            ],
            model="llama3-70b-8192",
        )

        description = chat_completion.choices[0].message.content
        return jsonify({"description": description})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
