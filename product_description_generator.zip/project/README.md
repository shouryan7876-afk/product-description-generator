# ProductCopy — AI Product Description Generator

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Set your Groq API key:
   ```
   # Linux/macOS
   export GROQ_API_KEY=your_key_here

   # Windows
   set GROQ_API_KEY=your_key_here
   ```

3. Run the app:
   ```
   python app.py
   ```

4. Open http://localhost:5000 in your browser.

## Project Structure

```
project/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
```

## Features
- Clean editorial-style UI
- Product name + category inputs
- Groq LLaMA 3 70B generation
- Loading indicator
- Copy to clipboard
- Error handling
